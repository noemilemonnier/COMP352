package a1_40001085;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**This method is the linear method for the Tetranacci Number
 * It is composed of a main class and a getTetranacciFunctionclass which will do the operations to obtain the T(n)
 * In the main class there is a printwriter declared to print out the output on a textfile "out.txt", a for loop
 * to execute T(n) where n is every multiple of 5, and a start and stop time to get the running time.
 * In the getTetranacciFunction class, there an array declared as tempArray that will stock the 4 first numbers of the
 * Tetranacci sequence which allows to do the calculation of the rest of the sequence. With the else statement so when k>3,
 * another array is declared and will get the value for k-1, and will continue until it gets to k=3 to fetch the values of
 * tempArray, and will do the calculate then for k+1 until obtaining k. Values at array[1], [2], [3] will be stocked in variable
 * but to get the sum of all number preceding it will be in var4 = sum of array[0-3] and by not stock array[0] in a variable
 * nor declaring it in the return statement it will create a moving movement until k is obtained
 * 
 * 
 * 
 * @author noemilemonnier
 *
 */

public class LinearTetranacci {

	//throws filenotfoundexception in case the "out.txt" is not located properly
	public static void main(String[] args) throws FileNotFoundException {
		//declare the printwriter to be able to send output to the textfile "out.txt"
		PrintWriter writerToTextFile = new PrintWriter("/Users/noemilemonnier/Documents/workspace/a1_40001085/src/a1_40001085/out.txt");
		System.out.println("This is from the linear recursive method.");
		//for loop to print out the T(n) and n being a multiple of 5, starting at 5 
		for(int i=5; i<=100; i=i+5){
			//create an array to stock the data from the function called for i
			long[] tetraNb = getTetranacciFunction(i);
			long startTime = System.nanoTime(); //in nano second because the time is too little
			long stopTime = (System.nanoTime()-startTime); //so we get accurate time of process
			// prints out each time the result at index i with stoptime & prints out also in textfile "out.txt"
			System.out.println("Tetranacci(" + i + ") = " +  tetraNb[3] + " with a time in nanoseconds of " + stopTime);
			writerToTextFile.println("Tetranacci(" + i + ") = " +  tetraNb[3] + " with a time in nanoseconds of " + stopTime);
		}
		writerToTextFile.close();
	}
	/** Class to find the tetranacci number at T(n) : uses if, else statement with an array of size 4
	 * 
	 * @param k
	 * @return an array with the desired number and the 4 preceding the desired number
	 */
	public static long[] getTetranacciFunction(int k){
		// the initial array contains the first 4 numbers of the tetranacci sequence to allow to find the rest
		long[] tempArray = {0,0,0,1};
		if (k == 0 || k == 1 || k == 2 || k==3){
			return tempArray;
		}
		else{
			//declare a new array to get the value of k-1 until we get a value and we can re-adjust the array values
			long[] array = getTetranacciFunction(k-1);
			long var1 = array[1]; 
			long var2 = array[2];
			long var3 = array[3];
			long var4 = array[0] + array[1]+ array[2]+ array[3]; 
			// array[0] is not in a variable because it allows the array to add new number and continue the sequence
			return new long[] {var1, var2, var3 , var4};
		}
	}

}
