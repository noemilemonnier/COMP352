package a1_40001085;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**This method is the exponential method for the Tetranacci Number
 * It is composed of a main class and a tetranacciRecusion class which will do the operations to obtain the T(n)
 * In the main class there is a printwriter declared to print out the output on a textfile "out.txt", a for loop
 * to execute T(n) where n is every multiple of 5, and a start and stop time to get the running time.
 * The tetranacciRecusion class is used by being divided in if-else if-else statement in case n>4 and in else it 
 * will do a recursive call 4 times. 
 * 
 * @author noemilemonnier
 *
 */
public class ExponentialTetranacci {
	//throws filenotfoundexception in case the "out.txt" is not located properly
	public static void main(String[] args) throws FileNotFoundException {
		//declare the printwriter to be able to send output to the textfile "out.txt"
		PrintWriter writerToTextFile = new PrintWriter("/Users/noemilemonnier/Documents/workspace/a1_40001085/src/a1_40001085/out.txt");
		System.out.println("This is from the exponential recursive method.");
		//for loop to print out the T(n) and n being a multiple of 5, starting at 5 
		for(int i=5; i<=100; i=i+5){
			long tetraNb = tetranacciRecusion(i); 		//calls the methods for i
			long startTime = System.nanoTime(); 		//in nanoseconds because the time is too little
			long stopTime = (System.nanoTime()-startTime); 		//so we get accurate time of process
			// prints out each time the result at index i with stoptime & prints out also in textfile "out.txt"
			System.out.println("Tetranacci(" + i + ") = " +  tetraNb + " with a time in nanoseconds of " + stopTime);
			writerToTextFile.println("Tetranacci(" + i + ") = " +  tetraNb + " with a time in nanoseconds of " + stopTime);
		}
		writerToTextFile.close();
	}
	/**Class to find the tetranacci number at T(n) : uses if,else if, else statement in case n>4
	 * 
	 * @param n  which is T(n) to get the tetranacci result
	 * @return  the value of the mathematical function
	 */
	public static int tetranacciRecusion(int n) {
		// if and else if are the predefined tetranacci numbers to allow to find the rest of the sequence
		if (n == 0 || n == 1 || n == 2) {
			return 0;
		}
		else if(n == 3){
			return 1;
		}
		else{
			return tetranacciRecusion(n - 1) + tetranacciRecusion(n - 2) + tetranacciRecusion(n - 3)+ tetranacciRecusion(n - 4);
		}
	}
}
