package a4;

import java.util.Iterator;
/*
 * @author melodie thibeault
 * @author noemi lemonnier
 * 
 * This is the AVLtree class it implements the interface Structure.
 * It has a AVLNode class which will create each node of the AVL tree.
 * It has a stack that is used by the public Iterator and private Iterator.
 * It also has many methods such as add, remove, rebalance, rotations methods, height, size, depth, and the methods in the Structure interface.
 */

public class AVLTree implements Structure{
	

	/*
		 * This is the class that will construct each Node of the AVL Tree.
		 * It will take a value, a Parent Node, a Left Node, a Right Node.
		 */
		
		private static class AVLNode {
			private String key;
			private Car value; 	// element containing information
			private AVLNode parentNode;
			private AVLNode leftNode;
			private AVLNode rightNode;
			private int balance;
			private int depth;
			private int height;
		/*
			 * Constructor of the AVLNode taking 4 parameters
			 */	
			public AVLNode(String license, Car value, AVLNode leftChild, AVLNode rightChild, AVLNode parent)
			{
				this.key = license;
				this.value = value;
				this.parentNode = parent;
				this.leftNode = leftChild;
				this.rightNode = rightChild;
				this.depth = 0;
				this.height = 0;
				this.balance = 0;
			}
		/*
			 * methods to verify if the node has a left child, has a right child, has two children
			 */	
			public boolean hasLeftChild() {
				return leftNode != null;
			}

			public boolean hasRightChild() {
				return rightNode != null;
			}

			public boolean hasTwoChildren(){
				return hasLeftChild() && hasRightChild();
			}
			
		/*
			 * methods to verify if the Node is a left child or is a right child or is external
			 */	
			public boolean isLeftChild() {
				return parentNode.leftNode == this;
			}

			public boolean isRightChild() {
				return parentNode.rightNode == this;
			}

			public boolean isExternal() {
				return leftNode == null && rightNode == null;
			}

			public String leftmostValue() {
				if (leftNode == null)
					return this.key;
				else
					return leftNode.leftmostValue();

			}

		}

	/*
		 * Stack is implemented to be able to use iterator through the Binary Search Tree
		 */	
		private static class Stack {

			private static class Node {
				private AVLNode node;
				private Node prev;

				public Node(AVLNode treeNode, Node previous) {
					node = treeNode;
					prev = previous;
				}
			}

			private Node last;

			public Stack() {
				last = null;
			}

			public void push(AVLNode node) {
				Node newNode = new Node(node, last);
				last = newNode;
			}

			public AVLNode pop() {
				AVLNode nodeToPop = last.node;
				last = last.prev;
				return nodeToPop;
			}

			public boolean isEmpty() {
				return last == null;
			}
		}
	/*
		 * AVLTree constructors
		 */

		private AVLNode root;

		
		public AVLTree(){
			root = null;
		}
		
		public AVLTree(String[] array)
		{
			Car car = new Car(null, null);
			root = new AVLNode(array[0], car, null, null, null);
			
			for (int i = 1; i<array.length; i++)
			{
				add(array[i], car);
			}
		}
	/*
		 * This is the method to add an element, it takes 2 parameters: String key, Car value
		 * It will create a new AVLNode and call the helper addToSubtree.
		 * Once the helper is done, it will call the method rebalanceTree.
		 * (non-Javadoc)
		 * @see a4_40001085.Structure#add(java.lang.String, a4_40001085.Car)
		 */
		
		@Override 
		public void add(String key, Car value) {

			AVLNode newNode = addToSubtree(key, value, root, root);
			if (newNode != null && newNode.parentNode != null)
				rebalanceTree(newNode.parentNode);
		}
		/* This is the helper method to add method, it takes 3 parameters: a String key, a Car value, a AVLNode subroot and a AVLNode newParent
		 * if the subroot is null it will make the element and reassign its parent. If the element needs to be
		 * to the left of the tree, it will  add it to the subroot left Node. Else it will add it to subroot right Node.
		 */
		private AVLNode addToSubtree(String key, Car value, AVLNode subroot, AVLNode newParent) {
			if (subroot == null)
			{		
				AVLNode newNode = new AVLNode(key, value, null, null, newParent);
				if (key.compareTo(newParent.key) < 0)
					newParent.leftNode = newNode;
				else
					newParent.rightNode = newNode;
				
				return newNode;
			}
			else if (key.compareTo(subroot.key) == 0)
			{
				value.setPrevious(subroot.value);
				subroot.value = value;
				return null;
			}
			else if (key.compareTo(subroot.key) < 0)
			{
				return addToSubtree(key, value, subroot.leftNode, subroot);
			}
			else if (key.compareTo(subroot.key) > 0)
			{
				return addToSubtree(key, value, subroot.rightNode, subroot);
			}
			
			return null;
		}


	/*
		 * Remove method takes an object
		 * It will check if the root is null, if yes  it won't remove anything. 
		 * Else  it will call the helper removeFromSubtree and once it is done.
		 * It will check if parentOfRemoved is not null, it will call the method rebalanceTree 
		 * else it will return false.
		 */
		public boolean remove(String license) {
			if (root == null)
				return false;

			AVLNode parentOfRemoved = removeFromSubtree(license, root);
			if (parentOfRemoved != null) // If a node was removed
			{
				rebalanceTree(parentOfRemoved);
				return true;
			}

			return false;
		}


	/*
		 * This is the helper method for  remove method
		 * it takes 2 parameters: a String license and a AVLNode subroot
		 *it will check if the license is at the left of the subroot or at the right of the subroot.
		 *If it is a the left, it will check if subroot left node is not null and make a recursive call, if it is
		 *not in the subroot left node, it will not remove. 
		 *If the license is in the right subroot, it will verify that the subroot right node is not null and make a recursive call, else it will not remove.
		 *
		 *Third condition is if the license is equal to the subroot value, then it needs to check if subroot has 2 children,
		 * if yes, then it will take the leftmost value of the subroot right Node to assign it to subroot and remove it.
		 * Else,  it will check if subroot is leftchild or right child and reassign the values.
		 */

		public AVLNode removeFromSubtree(String license, AVLNode subroot) {
			if (license.compareTo(subroot.key) < 0)
			{
				if (subroot.leftNode != null)
					return removeFromSubtree(license, subroot.leftNode);
				else
					return null;
			}
			else if (license.compareTo(subroot.key) > 0)
			{
				if (subroot.rightNode != null)
					return removeFromSubtree(license, subroot.rightNode);
				else
					return null;
			}
			else // element == subroot.value
			{
				if (subroot.value.getPrevious() != null)
				{
					Car toDelete = subroot.value;
					subroot.value = subroot.value.getPrevious();
					toDelete.setPrevious(null);
					return null; // No node removed
				}
				else if (subroot.hasTwoChildren()) // copies the next value (from inorder traversal) into the node then remove the copied value that is a leaf
				{
					subroot.key = subroot.rightNode.leftmostValue();
					removeFromSubtree(subroot.key, subroot.rightNode);
				}
				else if (subroot.isLeftChild())
				{
					if (subroot.hasLeftChild())
					{
						subroot.parentNode.leftNode = subroot.leftNode;
						subroot.leftNode.parentNode = subroot.parentNode;
						subroot.leftNode = null;
					}

					else
					{
						subroot.parentNode.leftNode = subroot.rightNode;
						subroot.rightNode.parentNode = subroot.parentNode;
						subroot.rightNode = null;
					}

				}
				else if(subroot.isRightChild())
				{
					if (subroot.hasLeftChild())
					{
						subroot.parentNode.rightNode = subroot.leftNode;
						subroot.leftNode.parentNode = subroot.parentNode;
						subroot.leftNode = null;
					}
					else
					{
						subroot.parentNode.rightNode = subroot.rightNode;
						subroot.rightNode.parentNode = subroot.parentNode;
						subroot.rightNode = null;
					}
				}
				AVLNode subrootParent = subroot.parentNode;
				subroot.parentNode = null;
				return subrootParent;
			}
		}

	/*
		 * method rebalanceTree takes 1 parameter: AVLNode node
		 * It calls setNodeBalances and then check if the node balance needs to be balanced 
		 * on the left side or right side and make the rotation method call depending on the situation.
		 */
		private void rebalanceTree(AVLNode node) {
			setNodeBalances();

			if (node.balance < -1) // must balance left side
			{
				if (getNodeHeight(node.leftNode.leftNode) >= getNodeHeight(node.leftNode.rightNode))
					node = rotationRight(node);
				else
					node = rotationLeftRight(node);

			} else if (node.balance > 1) { // Must balance right side
				if (getNodeHeight(node.rightNode.rightNode) >= getNodeHeight(node.rightNode.leftNode))
					node = rotationLeft(node);
				else
					node = rotationRightLeft(node);
			}

			if (node.parentNode != null) {
				rebalanceTree(node.parentNode);
			} else {
				root = node;
			}
		}

		/*
		 * Method SetNodeBalances will call setNodeHeights to make sure the height is calculated 
		 * after the change in the tree. It will call the nodeIterator and will verify where the balance is not correct
		 */
		private void setNodeBalances() {
			setNodeHeights();
			Iterator<AVLNode> it = nodeIterator();
			AVLNode currentNode;

			while(it.hasNext())
			{
				currentNode = it.next();
				currentNode.balance = getNodeHeight(currentNode.rightNode) - getNodeHeight(currentNode.leftNode);
			}
		}
	/*
		 * rotationRight takes 1 parameter: AVLNode aNode
		 * it will create a new AVLNode and instantiate it to aNode left Node, the bNode parent will be same 
		 * as aNode parent, and aNode left node will be assign to bNode right Node. 
		 * Once this is all assign, it will make sure aNode leftNode is not null;.
		 * It will reassign bNode right note and aNode parent Node. and then make sure bNode is not null.
		 * Once all reassignments are done, it calls setNodeBalances to make sure the Tree is balanced.
		 * It return bNode.
		 */
		
		private AVLNode rotationRight(AVLNode aNode) {

			AVLNode bNode = aNode.leftNode; 		
			bNode.parentNode = aNode.parentNode;
			aNode.leftNode = bNode.rightNode;

			if (aNode.leftNode != null)
				aNode.leftNode.parentNode = aNode; 

			bNode.rightNode = aNode; 
			aNode.parentNode = bNode; 

			if (bNode.parentNode != null) 
			{
				if (bNode.parentNode.rightNode == aNode) 
				{ 
					bNode.parentNode.rightNode = bNode;
				} else {
					bNode.parentNode.leftNode = bNode;
				}
			}

			setNodeBalances();

			return bNode;
		}
	/*
		 * rotationLeft takes 1 parameter: AVLNode aNode
		 * it will create a new AVLNode and instantiate it to aNode right Node, the bNode parent will be same 
		 * as aNode parent, and aNode right node will be assign to bNode left Node. 
		 * Once this is all assign, it will make sure aNode right node is not null;.
		 * It will reassign bNode left note and aNode parent Node. and then make sure bNode is not null.
		 * Once all reassignments are done, it calls setNodeBalances to make sure the Tree is balanced.
		 * It return bNode.
		 */
		private AVLNode rotationLeft(AVLNode aNode) {

			AVLNode bNode = aNode.rightNode;
			bNode.parentNode = aNode.parentNode;
			aNode.rightNode = bNode.leftNode;

			if (aNode.rightNode != null)
				aNode.rightNode.parentNode = aNode;

			bNode.leftNode = aNode;
			aNode.parentNode = bNode;

			if (bNode.parentNode != null) {
				if (bNode.parentNode.rightNode == aNode) {
					bNode.parentNode.rightNode = bNode;
				} else {
					bNode.parentNode.leftNode = bNode;
				}
			}

			setNodeBalances();

			return bNode;
		}

		/*
		 * rotationLeftRight takes 1 parameter: AVLNode nNode
		 * it will assign nNode left node by calling rotationLeft method and it will return by calling rotationRight method
		 */
		private AVLNode rotationLeftRight(AVLNode nNode) {
			nNode.leftNode = rotationLeft(nNode.leftNode);
			return rotationRight(nNode);
		}
		/*
		 * rotationRightLeft takes 1 parameter: AVLNode nNode
		 * it will assign nNode left node by calling rotationRight method and it will return by calling rotationLeft method
		 */
		private AVLNode rotationRightLeft(AVLNode nNode) {
			nNode.rightNode = rotationRight(nNode.rightNode);
			return rotationLeft(nNode);
		}

		/*
		 * This is the iterator class that requires the Stack class implemented.
		 * It is used to go through the binary search tree. We have 2 iterators: one public, one private.
		 * The public Iterator will return the nodes while the private  iterator will return the values.
		 */

		public Iterator<Car> iterator() {
			Iterator<Car> it = new Iterator<Car>() {
				private Stack stack = new Stack();
				private boolean stackInitialized = false;

				private void pushAllLeftChildren(AVLNode current) {
					while (current != null)
					{
						stack.push(current);
						current = current.leftNode;
					}
				}

				@Override
				public boolean hasNext() {
					return !stack.isEmpty();
				}

				@Override
				public Car next() {
					if (!stackInitialized)
					{
						pushAllLeftChildren(root);
						stackInitialized = true;
					}

					if (!hasNext()) {
						return null;
					}

					AVLNode popped = stack.pop();
					pushAllLeftChildren(popped.rightNode);
					return popped.value;
				}


				public void remove() {
					throw new UnsupportedOperationException();
				}
			};

			return it;
		}

		private Iterator<AVLNode> nodeIterator() {
			Iterator<AVLNode> it = new Iterator<AVLNode>() {
				private Stack stack = new Stack();
				private boolean stackInitialized = false;

				private void pushAllLeftChildren(AVLNode current) {
					while (current != null)
					{
						stack.push(current);
						current = current.leftNode;
					}
				}

				@Override
				public boolean hasNext() {
					if (!stackInitialized)
					{
						pushAllLeftChildren(root);
						stackInitialized = true;
					}
					return !stack.isEmpty();
				}

				@Override
				public AVLNode next() {

					if (!hasNext()) {
						return null;
					}

					AVLNode popped = stack.pop();
					pushAllLeftChildren(popped.rightNode);
					return popped;
				}

				@Override
				public void remove() {
					throw new UnsupportedOperationException();
				}
			};

			return it;
		}

	/*
		 * 
		 * Method to determine the height of nodes
		 * It will check if there is a root, if not, then height is -1.
		 * Else it will call the method setNodeDepths and set an integer to root depth
		 * It will call the nodeIterator to go through the Tree and until the Iterator has no more Nodes
		 * it will check if the integer max is smaller than the iterator node depth, if yes it will reassign
		 * the integer max value.
		 * It return integer max.
		 */
		public int height() {
			if (root == null)
				return -1;

			setNodeDepths();
			int max = root.depth;
			Iterator<AVLNode> it = nodeIterator();

			while(it.hasNext())
			{
				if(it.next().depth > max)
					max = it.next().depth;
			}

			return max;
		}

		/*
		 *   method setNodeHeights, it will assign each node their heights
		 */
		private void setNodeHeights()
		{
			Iterator<AVLNode> it = nodeIterator();
			AVLNode currentNode;

			while(it.hasNext())
			{
				currentNode = it.next();
				currentNode.height = computeHeight(currentNode);
			}

		}
		/*
		 * computeHeight will compute the height of each node
		 */
		private int computeHeight(AVLNode node)
		{
			if (node == null || node.isExternal())
				return 0;
			else
			{
				int h, hLeft = 0, hRight = 0;
				hLeft = computeHeight(node.leftNode);
				hRight = computeHeight(node.rightNode);
				h = Math.max(hLeft, hRight);
				return 1+h;
			}

		}
		/* Accessor to get node height and take 1 parameter: AVLNode node
		 * 
		 * @param node
		 * @return node.height
		 */
		private int getNodeHeight(AVLNode node)
		{
			if (node != null)
				return node.height;
			return -1;
		}
		/*
		 * method setNodeDepths  calls nodeIterator and a Node 
		 * It will set the node depth by calling the method computeDepths
		 * 
		 */
		private void setNodeDepths() {

			Iterator<AVLNode> it = nodeIterator();
			AVLNode currentNode;

			while(it.hasNext())
			{
				currentNode = it.next();
				currentNode.depth = computeDepth(currentNode);
			}

		}
		/*
		 * Method ComputeDepths takes 1 parameter: AVLNode node.
		 * It will return the depth of each node.
		 */
		private int computeDepth(AVLNode node) {
			if (node == root)
				return 0;
			else
				return 1 + computeDepth(node.parentNode);
		}

	/*
		 * method size calls the Iterator to go through each node and instantiate an integer to count
		 * the number of nodes the iterator is going through.
		 * return integer count
		 */
		public int size() {
			Iterator<AVLNode> it = nodeIterator();
			int count = 0;
			while(it.hasNext())
			{
				count++;
				it.next();
			}
			return count;
		}
	/*
	 * Method allKeys return all keys as a sorted sequence
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#allKeys()
	 */
		@Override
		public String[] allKeys() {
			String[] arrKey = new String[size()];
			Iterator<AVLNode> it = nodeIterator();
			int index = 0;
			while (it.hasNext()){
				arrKey[index] = it.next().key;
				index++;
			}
			return arrKey;
		}

	/*
	 * Method getValues return the values of the given key
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#getValues(java.lang.String)
	 */
		@Override
		public Car getValues(String key) {

			AVLNode node = searchKey(key, root);
			if (node != null)
				return node.value;
			
			return null;

		}
	/*
	 * Method nextKey return the key for the successor of the given key
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#nextKey(java.lang.String)
	 */
		@Override
		public String nextKey(String key) {
			
			AVLNode node = searchKey(key, root);
			if (node != null)
				return node.leftmostValue();
			
			return null;
		}
	/*
	 * Method nextKey return the key for the predecessor of the given key
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#prevKey(java.lang.String)
	 */
		@Override
		public String prevKey(String key) {
			Iterator<AVLNode> it = nodeIterator();
			AVLNode current;
			AVLNode previous = null;
			while (it.hasNext()){
				current = it.next();
				if (current.key == key && previous != null){
					return previous.key;
				}
				else if (current.key == key && previous == null)
					return "This key is the first key of the list";

				previous = current;
			}

			return null;

		}
	/*
	 * Method previousCars will return a sequence in reverse chronological order
	 * of cars that shares the same key.
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#previousCars(java.lang.String)
	 */
		@Override
		public Car previousCars(String key) {
			return getValues(key);
		}

	/*
		 * Method searchKey is a binary search algorithm that takes 2 parameters:
		 * String key and AVLNode subroot.
		 */
		private AVLNode searchKey(String key, AVLNode subroot) {
			
			if (subroot == null)
				return null;
			else if (subroot.key == key)
				return subroot;
			else if (key.compareTo(subroot.key) < 0)
				return searchKey(key, subroot.leftNode);
			else
				return searchKey(key, subroot.rightNode);
			
		}


	}
