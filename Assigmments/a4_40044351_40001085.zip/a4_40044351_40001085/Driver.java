package a4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Driver {

	static Scanner inputStream = null;

	public static void main(String[] args) {

		String file1 = "500values.txt";
		String file2 = "1kvalues.txt";
		String file3 = "2kvalues.txt";
		String file4 = "5kvalues.txt";
		String file11 = "ar_test_file1.txt";
		String file12 = "ar_test_file2.txt";
		String file13 = "ar_test_file3.txt";

		long timeStart;
		long timeEnd;
		long time;

		timeStart = System.currentTimeMillis();
		SmartAR SAR1 = initializeSAR(file11);
		timeEnd = System.currentTimeMillis();
		time = timeEnd - timeStart;
		System.out.println("Read file + initialize structure: " + time);

		timeStart = System.currentTimeMillis();
		String[] sortedKeys1 = SAR1.allKeys();
		timeEnd = System.currentTimeMillis();
		time = timeEnd - timeStart;
		System.out.println("allKeys: " + time);
		//System.out.println(Arrays.toString(sortedKeys1);

		timeStart = System.currentTimeMillis();
		SAR1.nextKey("G4V42S");
		timeEnd = System.currentTimeMillis();
		time = timeEnd - timeStart;
		System.out.println("Next key: " + time);

		timeStart = System.currentTimeMillis();
		SAR1.nextKey("G4V42S");
		timeEnd = System.currentTimeMillis();
		time = timeEnd - timeStart;
		System.out.println("Previous key: " + time);

		timeStart = System.currentTimeMillis();
		SAR1.getValues("G4V42S");
		timeEnd = System.currentTimeMillis();
		time = timeEnd - timeStart;
		System.out.println("Get Values: " + time);

		timeStart = System.currentTimeMillis();
		SAR1.nextKey("G4V42SS");
		timeEnd = System.currentTimeMillis();
		time = timeEnd - timeStart;
		System.out.println("Add key: " + time);


		inputStream.close();
	}

	private static SmartAR initializeSAR(String fileName)
	{
		inputStream = initializeInputStream(fileName);
		String[] entries = getEntries(fileName);
		SmartAR SAR = new SmartAR(entries);
		return SAR;
	}

	private static Scanner initializeInputStream(String fileName)
	{
		try
		{
			inputStream = new Scanner(new FileInputStream(fileName));
		}
		catch (FileNotFoundException e)
		{
			System.out.println("Error opening the file " + fileName);
			System.exit(0);
		}

		return inputStream;
	}

	private static int getNumberOfEntries()
	{
		int count = 0;
		while (inputStream.hasNextLine()) // Loops until the end of file
		{
			inputStream.nextLine(); 
			count++; 
		}
		inputStream.close();
		return count;
	}

	private static String[] getEntries(String fileName)
	{
		int numberOfEntries = getNumberOfEntries();
		inputStream = initializeInputStream(fileName); // Re-opening the file to get the pointer back at the beginning of the file
		String[] entries = new String[numberOfEntries];
		String current;

		while (inputStream.hasNextLine()) // Reading the file and storing the information in the Book array
		{
			for (int i = 0; i<entries.length; i++)
			{
				current = inputStream.nextLine();
				entries[i] = current;
			}
		}

		return entries;
	}

}

