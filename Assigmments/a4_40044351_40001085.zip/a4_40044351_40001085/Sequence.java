package a4;

import java.util.ArrayList;
/*
 * @author melodie thibeault
 * @author noemi lemonnier
 *
 * This is the Sequence class it implements the interface Structure.
 * It has a constructor for the cell and a constructor for the Sequence.
 * It has many methods such as sort, allKeys, add, remove, searchKey,getValues, nextKey, prevKey, previousCars.
 */
public class Sequence implements Structure{

	/*
	 * Constructor for each cell index of the ArrayList
	 */
	private class Cell {

		private String license;
		private Car value;
		public Cell(String key, Car value){
			this.license = key;
			this.value = value;
		}

	}

	private ArrayList<Cell> sequence;

	/*
	 * Constructor Sequence to create the ArrayList containing Cell objects
	 */
	public Sequence(String[] array){
		this.sequence = new ArrayList<Cell>(array.length);
		Cell cell;
		Car car = new Car(null, null);
		for(int i = 0; i< array.length; i++){
			cell = new Cell(array[i], car);
			sequence.add(cell);
		}
	}

	/*
	 * Method sort takes one element: String[] input.
	 * It will sort in order the arrayList.
	 */
	public String[] sort(String[] input){
		int size = input.length;
		String temp;
		for (int i = 0; i < size; i++) {
			for (int j = 1; j < (size - i); j++) {
				if (input[j - 1].compareTo(input[j] ) > 0) {
					temp = input[j - 1];
					input[j - 1] = input[j];
					input[j] = temp;
				}
			}
		}

		return input;
	}

	/*
	 * Method allKeys return all keys and calls the method Sort
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#allKeys()
	 */
	@Override
	public String[] allKeys() { // sorted sequence
		String[] temp = new String[sequence.size()];
		for(int i =0; i< sequence.size(); i++){
			temp[i] = sequence.get(i).license;
		}
		sort(temp);
		return temp;
	}

	/*
	 * Method add takes 2 parameters: String key, Car value.
	 * It will first call the method searchKey and then, if the Cell object is not null it means the String key already exist in the ArrayList
	 * and it will only add the Car object to the already existing Cell object. Else it will create a new Cell object and add it to the
	 * ArrayList.
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#add(java.lang.String, a4_40001085.Car)
	 */
	@Override
	public void add(String key, Car value) {

		Cell cell = searchKey(key);
		if (cell != null)
		{
			value.setPrevious(cell.value);
			cell.value = value;
		}
		else
		{
			Cell newCell = new Cell(key, value);
			sequence.add(newCell);
		}

	}
	/*
	 * Method searchKey takes 1 parameter: String key.
	 * It will go through the ArrayList and check if there's any Cell object that has the same key as the input.
	 * If there is, it will return the object Cell, else it will return null
	 */
	private Cell searchKey(String key) {

		for (int i = 0; i < sequence.size(); i++)
		{
			if (sequence.get(i).license.equals(key))
				return sequence.get(i);
		}
		return null;
	}
	/*
	 * Method remove takes 1 parameter: String key.
	 * It will first call the method searchKey and then, if the Cell object is not null it means the String key already exist in the ArrayList.
	 * It will then check if the Cell object has many Car object (check if it has a list of Cars), if yes, then it will remove the mo
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#remove(java.lang.String)
	 */
	@Override
	public boolean remove(String key) {
		Cell cell = searchKey(key);
		if( cell != null){
			if(cell.value.getPrevious() != null){
				Car temp = cell.value;
				cell.value = cell.value.getPrevious();
				temp.setPrevious(null);
				return true;
			}
			else{
				sequence.remove(cell);
				return true;
			}
		}
		return false;

	}
	/*
	 * Method getValues return the values of the given key
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#getValues(java.lang.String)
	 */
	@Override
	public Car getValues(String key) {
		Cell cell = searchKey(key);
		if(cell != null){
			return cell.value;
		}
		return null;
	}
	/*
	 * Method nextKey return the key for the successor of the given key
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#nextKey(java.lang.String)
	 */
	@Override
	public String nextKey(String key) {
		String[] allKeys = allKeys();
		for (int i = 0; i < allKeys.length; i++)
		{
			if (allKeys[i].equals(key))
				return allKeys[i+1];
		}
		return null;

	}

	/*
	 * Method nextKey return the key for the predecessor of the given key
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#prevKey(java.lang.String)
	 */
	@Override
	public String prevKey(String key) {
		String[] allKeys = allKeys();
		
		for (int i = 0; i < allKeys.length; i++)
		{
			if (allKeys[i].equals(key))
				return allKeys[i-1];
		}
		return null;

	}

	/*
	 * Method previousCars will return a sequence in reverse chronological order
	 * of cars that shares the same key.
	 * (non-Javadoc)
	 * @see a4_40001085.Structure#previousCars(java.lang.String)
	 */
	@Override
	public Car previousCars(String key) {
		return getValues(key);
	}



}
