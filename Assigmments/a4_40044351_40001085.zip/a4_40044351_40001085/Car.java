package a4;
/*
 * @author melodie thibeault
 * @author noemi lemonnier
 * 
 * The Car class is used to create objects of type Car that will be used by the AVLTree and the Sequences classes.
 * It has a constructor and getters and setters.
 */

public class Car {

	private String value;
	private Car previous;
	//private Car next;

	
	
	public Car(String value, Car previousCar){
		this.value = value;
		this.previous = previousCar;
		
	}


	/*
	 * Accessors and Getters for the instance variables
	 */

	public String getValue() {
		return value;
	}

	public void setTypeCar(String value) {
		this.value = value;
	}

	public Car getPrevious() {
		return previous;
	}

	public void setPrevious(Car previous) {
		this.previous = previous;
	}


}
