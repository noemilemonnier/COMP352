package a4;
/*
 * @author melodie thibeault
 * @author noemi lemonnier
 * 
 * This interface is used to provide the basic methods that will be shared by both data structures.
 */
public interface Structure {

	public String[] allKeys();
	public void add(String key, Car value); 
	public boolean remove(String key); //remove key. 
	public Car getValues(String key);
	public String nextKey(String key);
	public String prevKey(String key);
	public Car previousCars(String key);
	

	
	
}
