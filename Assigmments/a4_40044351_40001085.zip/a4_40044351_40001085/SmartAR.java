package a4;
/*
 * @author melodie thibeault
 * @author noemi lemonnier
 *
 *The class SmartAR is used to test both AVLTree and Sequence classes.
 *It has a constructor and different required methods such as: setThreshold, setKeyLength, generate, getRandomKey, 
 *allKeys, add, remove, getValues, nextKey, prevKey and previousCars.
 *To test both AVLTree and Sequence classes, it will use the methods above.
 */
public class SmartAR {
	// Set default values
	int threshold = 10000;
	int keyLength = 6;
	Structure smartAR;
	/*
	 * constructor
	 * if the size of the array.length is smaller than 10,000 elements the smartAR will be a Sequence, else a AVLTree
	 */
	public SmartAR(String[] array) {
		if (array.length < threshold)
			smartAR = new Sequence(array);
		else
			smartAR = new AVLTree(array);
	}

	/*
	 * setter for threshold, takes one parameter: int i
	 */
	public void setThreshold(int i){
		if (i >= 100 && i <= 500000)
			threshold = i;
	}
/*
 * setter for keyLength, takes one parameter: int length
 */
	public void setKeyLength(int length){
		if (length >= 6 && length <= 12)
			keyLength = length;
	}
/*
 * method generate takes one parameter: int n
 * It randomly generates a sequence containing n new non-existing keys of alphanumeric characters
 */
	public String[] generate(int n){
		String[] randomKeys = new String[n];
		int index = 0;
		String key;
		while (n > 0)
		{
			key = getRandomKey();
			if (smartAR.getValues(key) == null) // if the key doesn't already exist
			{
				randomKeys[index] = key;
				index++;
				n--;
			}
		}

		return randomKeys;

	} 
/*
 * Method getRandom will generate random sequence of n keys for any key.
 */
	private String getRandomKey() {
		String pool = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		int randomIndex;
		String key = "";

		for (int i = 0; i < keyLength ; i++)
		{
			randomIndex = (int)(Math.random() * pool.length());
			key += pool.charAt(randomIndex);
		}

		return key;

	}
/*
 * Method allKeys will call the same named method in the appropriate class, depending on the data structure of SmartAR
 */
	public String[] allKeys() {
		return smartAR.allKeys();
	}
/*
 * Method add takes 2 parameters: String key, Car value
 * It will call the same named method in the appropriate class, depending on the data structure of SmartAR
 */
	public void add(String key, Car value) {
		smartAR.add(key, value);
	}
	/*
	 * Method remove takes 1 parameters: String key
	 * It will call the same named method in the appropriate class, depending on the data structure of SmartAR
	 */
	public boolean remove(String key) {
		return smartAR.remove(key);
	}
	/*
	 * Method getValues takes 1 parameters: String key
	 * It will call the same named method in the appropriate class, depending on the data structure of SmartAR
	 */
	public Car getValues(String key) {
		return smartAR.getValues(key);
	}
	/*
	 * Method nextKey takes 1 parameters: String key
	 * It will call the same named method in the appropriate class, depending on the data structure of SmartAR
	 */
	public String nextKey(String key) {
		return smartAR.nextKey(key);
	}
	/*
	 * Method prevKey takes 1 parameters: String key
	 * It will call the same named method in the appropriate class, depending on the data structure of SmartAR
	 */
	public String prevKey(String key) {
		return smartAR.prevKey(key);
	}
	/*
	 * Method previousCars takes 1 parameters: String key
	 * It will call the same named method in the appropriate class, depending on the data structure of SmartAR
	 */
	public Car previousCars(String key) {
		return smartAR.previousCars(key);
	}
}
