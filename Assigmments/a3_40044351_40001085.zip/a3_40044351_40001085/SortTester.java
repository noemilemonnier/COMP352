

/*
 * This class is used to see how efficient is  TreeSort, A3AVLTree, and A3BSTree classes.
 * It has 6 instantitiate arrays that will go through AVL and BST sort in the TreeSort class as being unsorted and then being reversed sorted.
 * Informations about their time performance will be print out.
 * 
 * @autor melodiethibeault 
 * @autor noemilemonnier
 */

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class SortTester {

	private static PrintWriter outputStream = null;
	
	public static void main(String[] args) {		
		
		outputStream = initializeOutputStream(outputStream); // for the output text file

		// to call the treeSort functions
		TreeSort <Integer> AVLt = new TreeSort <Integer>();
		TreeSort <Integer> BSTt = new TreeSort <Integer>();
		
		String unsortedTime, reverseTime;

		// integer array with required sizes
		Integer a [] = new Integer[1];
		generateRandomArray(a);	// generates elements depending on array size
		unsortedTime = unsortedArrayTime(AVLt, BSTt, a);
		System.out.println(unsortedTime); 
		outputStream.println(unsortedTime);
		generateReverseSortedArray(a);	//sort the array in reverse order
		reverseTime = reverseSortedArrayTime(AVLt, BSTt, a);
		System.out.println(reverseTime);
		outputStream.println(reverseTime);
		
		Integer b [] = new Integer[10];
		generateRandomArray(b);
		unsortedTime = unsortedArrayTime(AVLt, BSTt, b);
		System.out.println(unsortedTime); 
		outputStream.println(unsortedTime);
		generateReverseSortedArray(b);	//sort the array in reverse order
		reverseTime = reverseSortedArrayTime(AVLt, BSTt, b);
		System.out.println(reverseTime);
		outputStream.println(reverseTime);
		
		
		Integer c [] = new Integer[100];
		generateRandomArray(c);
		unsortedTime = unsortedArrayTime(AVLt, BSTt, c);
		System.out.println(unsortedTime); 
		outputStream.println(unsortedTime);
		generateReverseSortedArray(c);	//sort the array in reverse order
		reverseTime = reverseSortedArrayTime(AVLt, BSTt, c);
		System.out.println(reverseTime);
		outputStream.println(reverseTime);
		
		
		Integer d [] = new Integer[1000];
		generateRandomArray(d);
		unsortedTime = unsortedArrayTime(AVLt, BSTt, d);
		System.out.println(unsortedTime); 
		outputStream.println(unsortedTime);
		generateReverseSortedArray(d);	//sort the array in reverse order
		reverseTime = reverseSortedArrayTime(AVLt, BSTt, d);
		System.out.println(reverseTime);
		outputStream.println(reverseTime);
		
		
		Integer e [] = new Integer[10000];
		generateRandomArray(e);
		unsortedTime = unsortedArrayTime(AVLt, BSTt, e);
		System.out.println(unsortedTime); 
		outputStream.println(unsortedTime);
		generateReverseSortedArray(e);	//sort the array in reverse order
		reverseTime = reverseSortedArrayTime(AVLt, BSTt, e);
		System.out.println(reverseTime);
		outputStream.println(reverseTime);
		
		
		Integer f [] = new Integer[100000];
		generateRandomArray(f);
		unsortedTime = unsortedArrayTime(AVLt, BSTt, f);
		System.out.println(unsortedTime); 
		outputStream.println(unsortedTime);
		generateReverseSortedArray(f);	//sort the array in reverse order
		reverseTime = reverseSortedArrayTime(AVLt, BSTt, f);
		System.out.println(reverseTime);
		outputStream.println(reverseTime);
		
		outputStream.close();

	}
	
	/*
	 * method generateRandomArray takes one parameter : int size
	 * It will create an array with random numbers depending of the size selected
	 */
	public static void generateRandomArray(Integer[] array)
	{
		for (int i = 0; i<array.length; i++)
		{
			array[i] = (int)(Math.random()*array.length + 1);
		}
	} 

	/*
	 * method generateReverseSortedArray takes one parameter: Integer[] arr
	 * It will use two for loop to go through the array and sorting it and then classing it
	 * in reverse order.
	 */
	public static void generateReverseSortedArray(Integer[] arr){
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				int temp = 0;

				if (arr[i] < arr[j]) { 	
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	
	/*
	 * method unsortedArrayTime takes 3 parameters: TreeSort <Integer> AVLt, TreeSort <Integer> BSTt, Integer[] arr
	 * it has 2 star time and 2 stop time to monitor how fast it takes the program to sort for the BST and AVL trees
	 * it returns a string with all information needed
	 */
	
	public static String unsortedArrayTime(TreeSort <Integer> AVLt, TreeSort <Integer> BSTt , Integer[] arr){
		long startTime = System.nanoTime();
		A3BSTree <Integer> BSTree = new A3BSTree<Integer>();
		TreeSort.sort(arr);
		long stopTime = System.nanoTime();
		long startTime2 = System.nanoTime();
		TreeSort.sort(BSTree, arr);
		long stopTime2 = System.nanoTime();
		long elapsedTime = stopTime - startTime;
		long elapsedTime2 = stopTime2 - startTime2;
		return "N = " + arr.length + "\nBST : " + elapsedTime2 + " NS" + "\nAVL: " + elapsedTime + " NS";
	}
	
	/*
	 * method reverseSortedArrayTime takes 3 parameters: TreeSort <Integer> AVLt, TreeSort <Integer> BSTt, Integer[] arr
	 * it has 2 star time and 2 stop time to monitor how fast it takes the program to sort for the BST and AVL sort
	 * it returns a string with all information needed about the array size, the time for unsorted array with BST and AVL sort
	 */
	public static String reverseSortedArrayTime(TreeSort <Integer> AVLt, TreeSort <Integer> BSTt , Integer[] arr){
		long startTime = System.nanoTime();// AVL
		A3BSTree <Integer> BSTree = new A3BSTree<Integer>();
		TreeSort.sort(arr);
		long stopTime = System.nanoTime();
		long startTime2 = System.nanoTime();//  BST
		TreeSort.sort(BSTree, arr);
		long stopTime2 = System.nanoTime();
		long elapsedTime = stopTime - startTime;
		long elapsedTime2 = stopTime2 - startTime2;
		return "BST (rev-sorted): " + elapsedTime2 + " NS" + "\nAVL (rev-sorted): " + elapsedTime + " NS\n";
	}

	
	/**
	 * Method to initialize the output stream and throw/catch the exception
	 * @param outputStream a PrintWriter object
	 * @return the PrintWriter object
	 */
	private static PrintWriter initializeOutputStream(PrintWriter outputStream)
	{
		try
		{
			outputStream = new PrintWriter(new FileOutputStream("SortTesterOutput.txt", true)); // Appending to the text file
		}
		catch (FileNotFoundException e)
		{
			System.out.println("Error opening the file");
			System.exit(0);
		}
		
		return outputStream;
	}

}
