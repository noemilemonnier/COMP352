/* The class A3BSTree is a class that will create a binary search tree.
 * It has a BSTNode method, that construct Binary Search Tree Nodes, a Stack method, 
 * an Iterator method, constructors for the ABSTree, methods to add, remove a BSTNode, 
 * a size, height, depths methods. 
 * 
 * 
 * 
 *@autor noemilemonnier
 *@autor melodiethibeault 
 */
import java.util.Collection;
import java.util.Iterator;


public class A3BSTree <E extends Comparable<? super E>> implements Tree<E>{
/*
 * This is the class that will construct each Node of the Binary Search Tree.
 * It will take a value, a Parent Node, a Left Node, a Right Node.
 */
	private static class BSTNode<E> {
		private E value;
		private BSTNode<E> parentNode;
		private BSTNode<E> leftNode;
		private BSTNode<E> rightNode;
		private int depth;
		/*
		 * Constructor of the BSTNode taking 4 parameters
		 */
		public BSTNode(E element, BSTNode<E> leftChild, BSTNode<E> rightChild, BSTNode<E> parent)
		{
			value = element;
			parentNode = parent;
			leftNode = leftChild;
			rightNode = rightChild;
			depth = 0;
		}
		
		/*
		 * methods to verify if the node has a left child, has a right child, has two children
		 */
		public boolean hasLeftChild() {
			return leftNode != null;
		}
		
		public boolean hasRightChild() {
			return rightNode != null;
		}
		
		public boolean hasTwoChildren(){
			return hasLeftChild() && hasRightChild();
		}
		
		/*
		 * methods to verify if the Node is a left child or is a right child
		 */
		public boolean isLeftChild() {
			return parentNode.leftNode == this;
		}
		
		public boolean isRightChild() {
			return parentNode.rightNode == this;
		}
		
		public E leftmostValue() {
			if (leftNode == null)
				return value;
			else
				return leftNode.leftmostValue();
			
		}
		
	}
	/*
	 * Stack is implemented to be able to use iterator through the Binary Search Tree
	 */
	private static class Stack<E> {

		private static class Node<E> {
			private BSTNode<E> node;
			private Node<E> prev;

			public Node(BSTNode<E> treeNode, Node<E> previous) {
				node = treeNode;
				prev = previous;
			}
		}

		private Node<E> last;
		
		public Stack() {
			last = null;
		}
		
		public void push(BSTNode<E> node) {
			Node<E> newNode = new Node<E>(node, last);
			last = newNode;
		}
		
		public BSTNode<E> pop() {
			BSTNode<E> nodeToPop = last.node;
			last = last.prev;
			return nodeToPop;
		}
		
		public boolean isEmpty() {
			return last == null;
		}
	}

	
	private BSTNode<E> root;
	
	/*
	 * A3BSTree constructors
	 */
	public A3BSTree(){
		root = null;
	}
	
	public A3BSTree(E element) {
		root = new BSTNode<E>(element, null, null, null);
	}
/*
 * This is the method to add an element, if root is null then it will make the element
 * that needs to be added the root. Else it will call the helper addToSubtree.
 * (non-Javadoc)
 * @see Tree#add(java.lang.Object)
 */
	@Override
	public void add(E element) {
		if (root == null)
			root = new BSTNode<E>(element, null, null, null);
		else
			addToSubtree(element, root, root);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void addAll(Collection<? extends E> c) {
		
		Object[] col = c.toArray();
		
		for (int i = 0; i < col.length ; i++)
		{
			add((E)col[i]);
		}
		
	}
/*
 * This is the helper to the method add, it takes 3 parameters: an element, a BSTNode subroot and a BSTNode newParent
 * if the subroot is null it will make the element and reassign its parent. If the element needs to be
 * to the left of the tree, it will  add it to the subroot left Node. Else it will add it to subroot right Node.
 */
	private BSTNode<E> addToSubtree(E element, BSTNode<E> subroot, BSTNode<E> newParent) {
		if (subroot == null)
		{
			return new BSTNode<E>(element, null, null, newParent);
		}
		else if (element.compareTo(subroot.value) < 0)
		{
			subroot.leftNode = addToSubtree(element, subroot.leftNode, subroot);
			return subroot.leftNode;
		}
		else // element >= lastNode.value
		{
			subroot.rightNode = addToSubtree(element, subroot.rightNode, subroot);
			return subroot.rightNode;
		}
	}
	
	/*
	 * Remove method takes an object and it will check if the root is null,
	 * then it won't remove anything. Else it will call the helper removeFromSubtree.
	 * 
	 * (non-Javadoc)
	 * @see Tree#remove(java.lang.Object)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public boolean remove(Object o) { 
		if (root == null)
			return false;
	
		E element = (E)o;
		return removeFromSubtree(element, root);
	}
	
	/*
	 * This is the helper method for method remove, it takes 2 parameters: an element and a BSTNode<E> subroot
	 *it will check if the element is at the left of the subroot or at the right of the subroot.
	 *If it is a the left, it will check if subroot left node is not null and make a recursive call, if it is
	 *not in the subroot left node, it will not remove. If the element is in the right subroot, it will
	 *verify that the subroot right node is not null and make a recursive call, else it will not remove.
	 *
	 *Third condition is if the element is equal to the subroot value, then it needs to check if subroot has 2 children,
	 * if yes, then it will take the leftmost value of the subroot right Node to assign it to subroot and remove it.
	 * Else,  it will check if subroot is left child or right child and reassign the values.
	 */
	public boolean removeFromSubtree(E element, BSTNode<E> subroot) {
		if (element.compareTo(subroot.value) < 0)
		{
			if (subroot.leftNode != null)
				return removeFromSubtree(element, subroot.leftNode);
			else
				return false;
		}
		else if (element.compareTo(subroot.value) > 0)
		{
			if (subroot.rightNode != null)
				return removeFromSubtree(element, subroot.rightNode);
			else
				return false;
		}
		else // element == subroot.value
		{
			if (subroot.hasTwoChildren()) // copies the next value (from inorder traversal) into the node then remove the copied value that is a leaf
			{
				subroot.value = subroot.rightNode.leftmostValue();
				removeFromSubtree(subroot.value, subroot.rightNode);
			}
			else if (subroot.isLeftChild())
			{
				if (subroot.hasLeftChild())
				{
					subroot.parentNode.leftNode = subroot.leftNode;
					subroot.leftNode.parentNode = subroot.parentNode;
					subroot.leftNode = null;
				}
					
				else
				{
					subroot.parentNode.leftNode = subroot.rightNode;
					subroot.rightNode.parentNode = subroot.parentNode;
					subroot.rightNode = null;
				}
					
			}
			else if(subroot.isRightChild())
			{
				if (subroot.hasLeftChild())
				{
					subroot.parentNode.rightNode = subroot.leftNode;
					subroot.leftNode.parentNode = subroot.parentNode;
					subroot.leftNode = null;
				}
				else
				{
					subroot.parentNode.rightNode = subroot.rightNode;
					subroot.rightNode.parentNode = subroot.parentNode;
					subroot.rightNode = null;
				}
			}
			subroot.parentNode = null;
			return true;
		}
	}
	
	/*
	 * This is the iterator class that requires the Stack class implemented.
	 * It is used to go through the binary search tree. We have 2 iterators: one public, one private.
	 * The public Iterator will return the nodes while the private  iterator will return the values.
	 * (non-Javadoc)
	 * @see Tree#iterator()
	 */
	@Override
	public Iterator<E> iterator() {
		Iterator<E> it = new Iterator<E>() {
			private Stack<E> stack = new Stack<E>();
			private boolean stackInitialized = false;
	        
	        private void pushAllLeftChildren(BSTNode<E> current) {
	        	while (current != null)
	        	{
	        		stack.push(current);
	        		current = current.leftNode;
	        	}
	        }

	        @Override
	        public boolean hasNext() {
	            return !stack.isEmpty();
	        }

	        @Override
	        public E next() {
	        	if (!stackInitialized)
	        	{
	        		pushAllLeftChildren(root);
	        		stackInitialized = true;
	        	}
	        	
	            if (!hasNext()) {
	            	return null;
	            }
	            
	            BSTNode<E> popped = stack.pop();
	            pushAllLeftChildren(popped.rightNode);
	            return popped.value;
	        }
	        
            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
	        };
	        
        return it;
	}
	
	private Iterator<BSTNode<E>> nodeIterator() {
		Iterator<BSTNode<E>> it = new Iterator<BSTNode<E>>() {
			private Stack<E> stack = new Stack<E>();
			private boolean stackInitialized = false;
	        
	        private void pushAllLeftChildren(BSTNode<E> current) {
	        	while (current != null)
	        	{
	        		stack.push(current);
	        		current = current.leftNode;
	        	}
	        }

	        @Override
	        public boolean hasNext() {
	            return !stack.isEmpty();
	        }

	        @Override
	        public BSTNode<E> next() {
	        	if (!stackInitialized)
	        	{
	        		pushAllLeftChildren(root);
	        		stackInitialized = true;
	        	}
	        	
	            if (!hasNext()) {
	            	return null;
	            }
	            
	            BSTNode<E> popped = stack.pop();
	            pushAllLeftChildren(popped.rightNode);
	            return popped;
	        }
	        
            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
	        };
	        
        return it;
	}
	/*
	 * Method to determine the height of nodes
	 * It will check if there is a root, if not, then height is -1.
	 * Else it will call the method setNodeDepths and set an integer to root depth
	 * It will call the nodeIterator to go through the Tree and until the Iterator has no more Nodes
	 * it will check if the integer max is smaller than the iterator node depth, if yes it will reassign
	 * the integer max value.
	 * It return integer max.
	 * (non-Javadoc)
	 * @see Tree#height()
	 */
	@Override
	public int height() {
		if (root == null)
			return -1;
		
		setNodeDepths();
		int max = root.depth;
		Iterator<BSTNode<E>> it = nodeIterator();
		
		while(it.hasNext())
		{
			if(it.next().depth > max)
				max = it.next().depth;
		}
		
		return max;
	}
	/*
	 * method setNodeDepths  calls nodeIterator and a Node to get the nodes and compute their Depths for each Node.
	 * 
	 */
	private void setNodeDepths() {
		
		Iterator<BSTNode<E>> it = nodeIterator();
		BSTNode<E> currentNode;
		
		while(it.hasNext())
		{
			currentNode = it.next();
			currentNode.depth = computeDepth(currentNode);
		}

	}
	/*
	 * Method ComputeDepths takes 1 parameter: BSTNode<E> node.
	 * It will return the depth of each node.
	 */
	private int computeDepth(BSTNode<E> node) {
		if (node == root)
			return 0;
		else
			return 1 + computeDepth(node.parentNode);
	}
	/*
	 * method size calls the Iterator to go through each node and instantitiate an integer to count
	 * the number of nodes the iterator is going through.
	 * return integer count
	 * (non-Javadoc)
	 * @see Tree#size()
	 */
	@Override
	public int size() {
		Iterator<E> it = iterator();
		int count = 0;
		while(it.hasNext())
		{
			count++;
			it.next();
		}
		return count;
	}

}
