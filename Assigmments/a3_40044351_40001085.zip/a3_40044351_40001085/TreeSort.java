/* This class is used to take an array and put it in a Binary Seearch tree or a balanced Binary Search Tree
 * and it should be sorted by the Trees.
 * 
 * @autor melodiethibeault 
 * @autor noemilemonnier
 */

public class TreeSort<E>{
	/** Sorts an array using TreeSort with a balanced AVL implementation 
	 * @param a an array to sort
	 */
	public static <E> void sort(Integer[] a){
		A3AVLTree <Integer> tree = new A3AVLTree<Integer>();
		for(int  i=0; i< a.length; i++){
			tree.add(a[i]);
		}
	}

	/**
	 * Sorts an array using TreeSort with a specified BST
	 * @param tree tree to use
	 * @param a an array to sort
	 */
	public static <E> void sort(A3BSTree <Integer> tree, Integer[] a){
		for(int i =0; i< a.length; i++){
			tree.add(a[i]);
		}

	}


}
