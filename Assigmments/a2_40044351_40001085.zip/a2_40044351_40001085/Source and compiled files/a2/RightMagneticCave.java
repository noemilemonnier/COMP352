package a2;

import java.util.Arrays;

/**
 * This is the recursive version of the algorithm to determine whether the game configuration is solvable or not.
 * @author M�lodie Thibeault (40044351) and No�mi Lemonnier (40001085)
 */
public class RightMagneticCave {
	
	/**
	 * This is the main method to test our algorithm
	 * @param args
	 */
	public static void main(String[] args) 
	{	
		// Array of 7 predefined arrays for testing purposes
		int[][] A  = {{8, 16, 10, 4, 6, 10, 2, 12, 8, 0},  // Example from handout
				{10, 16, 4, 6, 2, 10, 0}, // Example from handout
				{2, 3, 7, 10, 11, 2, 4, 9, 1, 0},
				{2, 2, 2, 0}, // Obviously true 
				{20, 5, 8, 3, 8, 9, 15, 11, 10, 4, 5, 9, 0},
				{1, 2, 3, 4, 6}, // Invalid array (no 0 in last position)
				{2, 4, 3, 4, 5, 0}
				};

		boolean result;

		for (int i = 0; i<A.length; i++) // For every array in the array
		{			
			result = searchPath(A[i], 0);  // Look for a path from start (index 0) to end (index n-1)
			
			System.out.println(Arrays.toString(A[i]) + " -> " + result); // Print the result
		}
		
		System.out.println("\n======== Random Arrays ========\n");
		
		// More arrays, this time generated randomly
		int[] randomArray;
		for (int i=0; i<20; i++)
		{
			randomArray = generateRandomArray();
			result = searchPath(randomArray, 0);
			System.out.println("#"+ ( i+1) +" "+ Arrays.toString(randomArray) + " -> " + result);
		}

	}
	
/** This method will take an array of integer and an integer as the starting position and checks if there is a path from the starting position to the end of A.
 * It automatically returns true if A = [0].
 * It automatically returns false if the starting index is out of bounds or if the last element of A is not 0. 
 * Else, it creates an array of boolean of the same length as A and calls searchPathRecursive.
 * 
 * @param A the array for the game
 * @param start the starting index in the array
 * @return boolean true if there is a path from the starting index to the end of the array
 */
	
	public static boolean searchPath(int[] A, int start)
	{	
		if (start < 0 || start > A.length-1 || A[A.length-1] != 0)  // If start index out of bounds OR last element in array is not 0
			return false;
		
		if (A.length == 1) // With the condition above, if the array is of length one and ends with 0 (ie A = [0]) then we are already at the winning position... 
			return true;
		
		int target = A.length-1; // Initial target is the last element of the array
		boolean[] visitedIndexes = new boolean[A.length]; // Create an array of boolean of the same length as the array
		
		return searchPathRecursive(A, start, target, visitedIndexes);
	}
	
	/** This method recursively looks for a path from the target index to the starting position and makes sure that a position is not visited twice. 
	 * For every element in the array, check if the element can reach the target and has not been visited: if that element is the index of the starting position, return true.
	 * If there's another element that can reach the previous element, and the starting position can reach that other element (recursion), then return true.
	 * Else look for another index that can reach the initial target.
	 * If everything fails, return false.
	 * 
	 * @param A the array for the game
	 * @param start the starting index in the array
	 * @param target the target index in the array
	 * @param visitedIndexes an array of booleans
	 * @return boolean true if there is a path from the starting index to the target index
	 */
	
	public static boolean searchPathRecursive(int[] A, int start, int target, boolean[] visitedIndexes) {
		
		visitedIndexes[target] = true; // The target(which is identify as last index) is the point where we start the search, so it is automatically visited
		
		for (int i = 0; i<A.length; i++)
		{
			if (visitedIndexes[i] != true && canReach(A, i, target)) // If we can reach the target from i and the index is not already visited
			{
				if (i == start) // If we can reach target from i, and i is the starting index, then there is a path
					return true;
				
				if (searchPathRecursive(A, start, i, visitedIndexes)) // If there is a path from i to target, then i becomes the new target.
					return true; //If the recursive call reached the base case and returned true, then there is a path from start to end and this method return true
					// Else we look for another index that can reach the target with a new loop iteration
			}
		}
		
		return false; // If nothing worked, then the puzzle is unsolvable
	}
	
	/** This method is used to check the different possible moves from index (to the right and to the left) depending if it is an even
	 * or odd element. 
	 * It will return true if one of the possible positions can reach the target index, or false otherwise.
	 * 
	 * @param A the array for the game
	 * @param index the marker current position
	 * @param target the target index
	 * @return boolean true if the current position can reach the target index
	 */
	
	public static boolean canReach(int[] A, int index, int target)
	{
		int steps; 
		
		if (A[index]%2 == 0) // If the element at A[index] is even
		{
			steps = A[index]/2;
			if (index + steps == target || index - steps == target) // If we can reach the target from the left or the right
				return true;
		}
		else // If the element at A[index] is odd
		{
			steps = A[index]/2 + 1;
			if (index + steps == target || index - steps == target) // If we can reach the target from the left or the right
				return true;
		}
		
		return false; 
	}
	
	/**This method is generates random arrays of size varying between 1 and 20 to test our recursion method
	 * 
	 * @return array a random array
	 */
	public static int[] generateRandomArray()
	{
		int size = (int)(Math.random()*20 + 1);
		int[] array = new int[size];

		for (int i = 0; i<array.length-1; i++)
		{
			array[i] = (int)(Math.random()*size + 1); // To improve the odds of getting valid arrays, the largest possible element is proportional to the size of the array
		}
		
		array[array.length-1] = 0; // Set 0 at the last index
		
		return array;
	} 

}
