package a2;

import java.util.Arrays;
import java.util.LinkedList;

/**
 * This is the iterative version of the algorithm to determine whether the game configuration is solvable or not.
 * It uses a Linked List.
 * @author M�lodie Thibeault (40044351) and No�mi Lemonnier (40001085)
 */
public class RightMagneticCave_List {
	
	/**
	 * This is the main method to test our algorithm
	 * @param args
	 */
	public static void main(String[] args)
	{
		// Array of 7 predefined arrays for testing purposes
		int[][] A  = {{8, 16, 10, 4, 6, 10, 2, 12, 8, 0},  // Example from handout
				{10, 16, 4, 6, 2, 10, 0}, // Example from handout
				{2, 3, 7, 10, 11, 2, 4, 9, 1, 0},
				{2, 2, 2, 0}, // Obviously true 
				{20, 5, 8, 3, 8, 9, 15, 11, 10, 4, 5, 9, 0},
				{1, 2, 3, 4, 6}, // Invalid array (no 0 in last position)
				{2, 4, 3, 4, 5, 0}
		};

		boolean result;

		for (int i = 0; i<A.length; i++) // For every array in the array
		{			
			if (A[i][A[i].length-1] != 0) // If there is no 0 at the last position, invalid array
				result = false;
			else
				result = searchPath(A[i], 0);  // Look for a path from start (index 0) to end (index n-1)

			System.out.println(Arrays.toString(A[i]) + " -> " + result); // Print the result
		}
		
		System.out.println("\n======== Random Arrays ========\n");
		
		// More arrays, this time generated randomly
		int[] randomArray;
		for (int i=0; i<20; i++)
		{
			randomArray = generateRandomArray();
			result = searchPath(randomArray, 0);
			System.out.println(Arrays.toString(randomArray) + " -> " + result);
		}
	}
	
/** This method takes in an array of integer and an integer start which indicates the marker start position in the array.
 * It will create a Linked List of integers and add the start index as it is the first node that is visited and accepted by the game. 
 * Then, for all elements in the linked list, if it links to a valid index in the array, then the valid index will be added to the linked list. 
 * If the last index of the array A is added to the linked list it will stop the method and return true. Otherwise it returns false.
 * 
 * @param A the array for the game
 * @param start the starting index
 * @return boolean true if there is a path from the start to the end of the array
 */
	public static boolean searchPath(int[] A, int start) 
	{
		LinkedList<Integer> accessibleNodes = new LinkedList<Integer>(); // A dynamic list that will contain indexes from A
		accessibleNodes.add(start);  // Add the starting position to the list
		
		for (int i = 0; i < accessibleNodes.size(); ++i)   // Note that the size of the list can grow after every iteration to a maximum size equal to A.length
		{
			
			// Take the indexes contained in the list and if these indexes can reach other indexes in A (that are not already in the list), add them to the list
			addIfValid(moveRight(accessibleNodes.get(i), A), accessibleNodes, A.length);
			addIfValid(moveLeft(accessibleNodes.get(i), A), accessibleNodes, A.length);     
			
			if(accessibleNodes.get(i) == A.length-1)  // Return if the last index of the array (our goal) is found in the list
				return true;
		}

		return false;
	}
	
	/** This method first checks if the index passed is not in the array or if it is already in the linked list, in which case
	 * nothing happens. Otherwise, the index is added to the linked list.
	 * 
	 * @param index the index we want to add in the linked list
	 * @param accessibleNodes the list of visited indexes
	 * @param arraySize the size of the array (as we do not need the array itself)
	 */
	public static void addIfValid(int index, LinkedList<Integer> accessibleNodes, int arraySize)
	{
		if (index < 0 || index > arraySize-1)  // Index out of bounds
			return;
		
		if (accessibleNodes.contains(index)) // Index already in the list
			return;
		
		accessibleNodes.add(index);
	}
	
	/** This method calculates the next index if we move integer pos (which represents the position
	 * of the marker in the array) on the right depending if this index contains an even or odd number. It will
	 * return that position.
	 * 
	 * @param pos the position of the marker on the array
	 * @param A the array
	 * @return integer the potential position of the marker if it moves right
	 */
	public static int moveRight(int pos, int[] A) {
		int position;
		if (A[pos]%2 == 0) //If the number at the position is even
		{
			position = pos + A[pos]/2;
		}
		else // The number is odd
		{
			position = pos + (A[pos]/2) + 1;
		}
		return position; 
	}
	
	/** This method calculates the next index if we move integer pos (which represents the position
	 * of the marker in the array) on the left depending if this index contains an even or odd number. It will
	 * return that position.
	 * 
	 * @param pos the position of the marker on the array
	 * @param A the array
	 * @return integer the potential position of the marker if it moves left
	 */
	public static int moveLeft(int pos, int[] A) {
		int position;
		if (A[pos]%2 == 0) //If the number at the position is even
		{
			position = pos - A[pos]/2;
		}
		else // The number is odd
		{
			position = pos - (A[pos]/2) - 1;
		}
		return position;
	}
	
	/**This method is generates random arrays of size varying between 1 and 20 to test our recursion method
	 * 
	 * @return array of integers
	 */
	public static int[] generateRandomArray()
	{
		int size = (int)(Math.random()*20 + 1);
		int[] array = new int[size];

		for (int i = 0; i<array.length-1; i++)
		{
			array[i] = (int)(Math.random()*size + 1);
		}
		
		array[array.length-1] = 0; // Set 0 at the last index
		
		return array;
	} 

}
